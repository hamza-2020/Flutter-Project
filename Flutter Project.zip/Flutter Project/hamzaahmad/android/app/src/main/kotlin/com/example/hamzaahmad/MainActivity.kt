package com.example.hamzaahmad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
